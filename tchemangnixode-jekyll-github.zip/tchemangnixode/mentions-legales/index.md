---
layout: page
title: Mentions légales
permalink: /mentions-legales/
---

## Éditeur du site

Tchémangnixodé est édité à titre indépendant. Pour toute demande relative à l'identité du responsable de publication, merci de nous contacter via la page Contact.

## Hébergement

Ce site est hébergé par GitHub, Inc. (GitHub Pages) — 88 Colin P. Kelly Jr. St, San Francisco, CA 94107, États-Unis.

## Propriété intellectuelle

L'ensemble des contenus publiés (textes, photographies, vidéos) sont la propriété de Tchémangnixodé ou de leurs auteurs respectifs, sauf mention contraire. Toute reproduction sans autorisation est interdite.

## Données personnelles

Les informations transmises via le formulaire de contact sont utilisées uniquement pour répondre à votre demande et ne sont jamais transmises à des tiers.

## Cookies

Ce site n'utilise pas de cookies de suivi publicitaire. Des cookies techniques peuvent être déposés par des services tiers intégrés (commentaires, vidéos).
