---
title: "Ganvié célèbre son patrimoine lacustre à l'occasion d'un nouveau festival"
categories: [culture]
author: Rédaction
excerpt: "La cité lacustre de Ganvié accueille la première édition d'un festival dédié à la valorisation du patrimoine culturel et artisanal de la région."
---

La cité lacustre de Ganvié, souvent présentée comme la « Venise de l'Afrique », a accueilli ce week-end la première édition d'un festival entièrement dédié à la valorisation de son patrimoine culturel et artisanal.

## Trois jours de célébrations

Pendant trois jours, pêcheurs, artisans et artistes locaux ont présenté leur savoir-faire aux visiteurs venus de tout le pays et de l'étranger. Démonstrations de pêche traditionnelle, expositions de sculptures sur bois et concerts de musiques traditionnelles ont rythmé l'événement.

Les organisateurs espèrent faire de ce festival un rendez-vous annuel incontournable, capable de renforcer l'attractivité touristique de la région tout en préservant les traditions locales face à la modernisation rapide du site.

## Une cité classée au patrimoine national

Ganvié a récemment été classée au patrimoine culturel national, une reconnaissance qui s'accompagne d'un programme de préservation face aux transformations rapides que connaît la cité lacustre.

Les responsables culturels locaux appellent à un soutien accru pour la restauration des habitations traditionnelles sur pilotis, menacées par l'érosion et les aléas climatiques.

*Ceci est un article de démonstration destiné à illustrer la mise en page du site. Remplacez ce contenu par vos propres articles.*
