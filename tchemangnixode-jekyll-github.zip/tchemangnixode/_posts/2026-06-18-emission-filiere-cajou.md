---
title: "Émission spéciale : entretien avec un acteur économique de la filière cajou"
categories: [videos]
author: Rédaction
excerpt: "Dans cette émission spéciale, nous recevons un acteur clé de la filière cajou béninoise pour décrypter les enjeux de la transformation locale."
---

Dans cette émission spéciale, notre rédaction reçoit un acteur clé de la filière cajou béninoise pour décrypter les enjeux économiques liés à la transformation locale de la noix brute.

<div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; border-radius: 2px; margin-bottom: 24px;">
  <iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;" frameborder="0" allowfullscreen title="Émission spéciale filière cajou"></iframe>
</div>

## Ce qu'il faut retenir

Notre invité revient sur les obstacles qui freinent encore l'industrialisation de la filière, ainsi que sur les opportunités qu'offre la demande internationale croissante pour les noix transformées localement.

L'émission complète, ainsi que toutes nos prochaines productions, est également disponible sur notre page Facebook, où elle est automatiquement partagée dès sa mise en ligne.

*Ceci est un article de démonstration destiné à illustrer la mise en page du site. Remplacez l'URL de la vidéo YouTube par vos propres contenus.*
