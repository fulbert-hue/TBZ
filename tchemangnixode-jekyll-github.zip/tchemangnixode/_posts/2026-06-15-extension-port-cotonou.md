---
title: "Cotonou : le projet d'extension du port entre dans sa phase active"
categories: [actualites]
author: Rédaction
excerpt: "Les travaux d'extension du port autonome de Cotonou ont officiellement débuté, avec pour objectif de doubler la capacité de traitement des conteneurs à l'horizon 2028."
---

Les travaux d'extension du port autonome de Cotonou ont officiellement débuté cette semaine, marquant une étape importante dans la modernisation des infrastructures portuaires du Bénin.

Ce projet, porté par le gouvernement en partenariat avec plusieurs bailleurs internationaux, vise à doubler la capacité de traitement des conteneurs à l'horizon 2028. Il s'inscrit dans une stratégie plus large de positionnement du Bénin comme hub logistique régional pour l'Afrique de l'Ouest.

## Un chantier de grande ampleur

Selon les autorités portuaires, les travaux comprennent la construction de deux nouveaux quais, la modernisation des équipements de manutention et l'aménagement de zones de stockage supplémentaires.

> Ce projet va transformer durablement la compétitivité de notre port et créer des milliers d'emplois directs et indirects.

Les retombées économiques attendues concernent particulièrement les secteurs de la logistique, du transport et du commerce transfrontalier avec les pays sahéliens enclavés.

## Calendrier des travaux

La première phase du chantier doit s'achever en 2027, avant la mise en service progressive des nouvelles installations. Des études d'impact environnemental ont été menées en amont du projet.

*Ceci est un article de démonstration destiné à illustrer la mise en page du site. Remplacez ce contenu par vos propres articles.*
