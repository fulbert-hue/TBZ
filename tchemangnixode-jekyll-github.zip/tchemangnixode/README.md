# Tchémangnixodé — Site web

Site Jekyll prêt à déployer sur GitHub Pages.

## 🚀 Déploiement (première fois)

1. **Crée un repository GitHub** nommé `tchemangnixode` (public) sur ton compte `fulbert-teinte`.

2. **Pousse ce dossier** vers ce repository :
   ```bash
   cd tchemangnixode
   git init
   git add .
   git commit -m "Premier déploiement du site Tchémangnixodé"
   git branch -M main
   git remote add origin https://github.com/fulbert-teinte/tchemangnixode.git
   git push -u origin main
   ```

3. **Active GitHub Pages** :
   - Va dans **Settings** > **Pages** de ton repository
   - Source : sélectionne la branche `main`, dossier `/ (root)`
   - Clique sur **Save**

4. Ton site sera en ligne dans 1 à 2 minutes à l'adresse :
   `https://fulbert-teinte.github.io/tchemangnixode/`

## ✍️ Publier un nouvel article

Crée un fichier dans `_posts/` nommé `AAAA-MM-JJ-titre-article.md` :

```markdown
---
title: "Titre de votre article"
categories: [actualites]
author: Rédaction
excerpt: "Résumé court de l'article, affiché sur la page d'accueil."
image: /assets/images/mon-image.jpg
---

Contenu de votre article ici, en Markdown.

## Un sous-titre

Du texte, des **gras**, des *italiques*, des [liens](https://exemple.com)...
```

**Catégories disponibles** : `actualites`, `politique`, `culture`, `videos`

Ajoute tes images dans `assets/images/` avant de les référencer.

Après modification, fais simplement :
```bash
git add .
git commit -m "Nouvel article : titre"
git push
```
Le site se met à jour automatiquement en 1-2 minutes.

## 📘 Connecter Facebook (publication automatique)

Voir le **Cahier des charges** (section 4) pour la configuration complète via Zapier ou IFTTT, en utilisant le flux RSS du site disponible à :
`https://fulbert-teinte.github.io/tchemangnixode/feed.xml`

## 📁 Structure du projet

```
tchemangnixode/
├── _config.yml          → configuration du site
├── _posts/               → tous les articles
├── _layouts/             → templates de page
├── _includes/            → header, footer
├── assets/css/           → styles
├── assets/images/        → images des articles
├── rubrique/             → pages des 4 rubriques
├── a-propos/             → page À propos
├── contact/              → page Contact (formulaire)
└── mentions-legales/     → page légale
```

## ⚙️ Avant la mise en ligne définitive

- [ ] Remplacer `VOTRE_ID_FORMSPREE` dans `contact/index.md` par ton vrai ID Formspree (inscription gratuite sur formspree.io)
- [ ] Remplacer les articles de démonstration par tes vrais articles
- [ ] Ajouter un vrai logo si souhaité
- [ ] Vérifier `_config.yml` (url, baseurl) si tu changes de nom de repo
