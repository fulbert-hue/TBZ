---
layout: page
title: À propos
permalink: /a-propos/
---

Tchémangnixodé est un média en ligne béninois né de l'envie de raconter le Bénin et l'Afrique avec exigence, proximité et indépendance.

Nous couvrons quatre grands domaines : l'**actualité** locale et internationale, la **politique** béninoise et sous-régionale, la **culture** et les événements qui font vivre nos villes et villages, ainsi que des **vidéos et émissions** pour aller plus loin que l'écrit.

## Notre ligne éditoriale

Informer juste, informer vite, mais jamais au détriment de la rigueur. Chaque article publié sur Tchémangnixodé est relu avant mise en ligne. Nous citons nos sources et corrigeons publiquement nos erreurs lorsqu'elles surviennent.

## Nous suivre

Le plus simple pour ne rien manquer : suivez notre page Facebook, où chaque nouvel article publié sur le site est automatiquement partagé.

<a href="{{ site.facebook_url }}" class="bouton" target="_blank" rel="noopener" style="margin-top: 12px;">Suivre sur Facebook →</a>
