---
layout: page
title: Contact
permalink: /contact/
---

Une information à nous transmettre, une erreur à signaler, une proposition de partenariat ? Écrivez-nous.

<form action="https://formspree.io/f/VOTRE_ID_FORMSPREE" method="POST" style="margin-top: 28px;">
  <div class="form-champ">
    <label for="nom">Nom complet</label>
    <input type="text" id="nom" name="nom" required>
  </div>
  <div class="form-champ">
    <label for="email">Adresse email</label>
    <input type="email" id="email" name="email" required>
  </div>
  <div class="form-champ">
    <label for="sujet">Sujet</label>
    <input type="text" id="sujet" name="sujet" required>
  </div>
  <div class="form-champ">
    <label for="message">Message</label>
    <textarea id="message" name="message" rows="6" required></textarea>
  </div>
  <button type="submit" class="form-bouton">Envoyer le message</button>
</form>

<p style="margin-top: 32px; font-size: 14px; color: var(--gris);">
  Vous pouvez aussi nous écrire directement sur
  <a href="{{ site.facebook_url }}" target="_blank" rel="noopener" style="color: var(--terracotta); text-decoration: underline;">notre page Facebook</a>.
</p>
